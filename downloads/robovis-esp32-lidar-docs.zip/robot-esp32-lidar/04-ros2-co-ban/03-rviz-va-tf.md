---
search:
  exclude: true
---

# RViz và kiểm tra TF

Nội dung này đã được chuyển sang **Kiến thức nền → Robot và ROS 2 cơ bản** và được biên soạn lại trong lộ trình chung.

[Mở bài học tại vị trí mới](https://manual.robovis.vn/kien-thuc-nen/robot-ros2/03-rviz-va-tf/)

[Xem toàn bộ lộ trình ROS 2](https://manual.robovis.vn/kien-thuc-nen/robot-ros2/) · [Về Robot ESP32 LiDAR](../index.md)
