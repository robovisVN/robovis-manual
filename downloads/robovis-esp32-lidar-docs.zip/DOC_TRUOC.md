# Bộ tài liệu Robot ESP32 LiDAR

Bắt đầu: [Robot ESP32 LiDAR](robot-esp32-lidar/index.md).

Gói này chứa các bài Markdown và hình minh họa hiện có. Không bao gồm bộ mã nguồn điều khiển, firmware hoặc máy ảo robot.

Mở bằng trình xem Markdown. Sơ đồ cần hỗ trợ Mermaid. Liên kết ra ngoài bộ tài liệu dẫn tới website và cần Internet.

Tài liệu trực tuyến: https://manual.robovis.vn/robot-esp32-lidar/
